# Independent rule-decision review

Extract this ZIP and open review.html locally. The page works without a server
and sends no answers anywhere. Enter your stable reviewer ID and Start / resume.
Use a separate browser profile from other reviewers. Download your CSV when
finished; browser storage is only a convenience, not a durable backup.

Judge all 60 items independently using only the visible snippet, question,
scenario and history. Choose Yes, No, Irrelevant, ASK or UNCLEAR and explain why.
ASK means a further question is needed; no particular wording must be generated.
Use UNCLEAR when conflicting or ambiguous text prevents a justified action.
Do not force an answer from outside knowledge. These are historical research
texts, not a request to apply today's law or policy. See ATTRIBUTION.md.

Do not inspect source answers, project analyses, or another person's review
before saving your initial answers. Work without AI assistance; disclose any
exposure, assistance or discussion that did occur in cover_note.txt. This is
a review procedure, not a restriction on your rights under the data license.
Return your exported CSV and cover note to the person who gave you this pack.
The blank_review.csv has the same IDs if you prefer a spreadsheet editor.
Do not change IDs or column names. Dates use YYYY-MM-DD.
