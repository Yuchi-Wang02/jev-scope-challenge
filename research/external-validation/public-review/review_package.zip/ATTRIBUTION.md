# ShARC source and package license

Source: ShARC — Shaping Answers with Rules through Conversation.
Creators: Marzieh Saeidi, Max Bartolo, Patrick Lewis, Sameer Singh,
Tim Rocktäschel, Mike Sheldon, Guillaume Bouchard, Sebastian Riedel.
Paper: Interpretation of Natural Language Rules in Conversational Machine Reading
(EMNLP 2018), https://aclanthology.org/D18-1233/
Project: https://sharc-data.github.io/
Official data/license notice: https://sharc-data.github.io/data.html
Source archive: https://sharc-data.github.io/data/sharc1-official.zip

License: Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0).
Deed: https://creativecommons.org/licenses/by-sa/3.0/
Legal code: https://creativecommons.org/licenses/by-sa/3.0/legalcode

This entire review package, including the source-derived selection, its
presentation and added instructions, is distributed under CC BY-SA 3.0.
The repository-wide MIT license does not replace this package license.
Keep attribution and license notices when redistributing; indicate adaptations
and distribute them under the same license. No additional legal restrictions
are imposed by our request to avoid source answers during independent review.

Changes by the Jev Scope Challenge project (AI-assisted), 2026-09-30:
selected 60 training inputs; retained snippet, question, scenario and history;
omitted source labels/evidence/metadata; assigned opaque review IDs; shuffled
items; added blank annotation fields and an offline review interface.
Visible source text is not rewritten. The package is not endorsed by the
ShARC authors. These historical rules are research material, not current advice.
No warranties are provided. The official archive had no separate license file;
the official data page supplies the distribution notice checked on this date.
